﻿namespace Questao5.Application.Commands.Requests
{
    public enum TipoMovimentoEnum
    {
        credito,
        debito
    }
}
